/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.29-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: vulnerable_sns
-- ------------------------------------------------------
-- Server version	10.5.29-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,303,11,'<','2025-11-20 14:50:37'),(2,303,11,'<S','2025-11-20 14:50:47'),(3,303,11,'<ScRiP','2025-11-20 14:51:03'),(4,303,11,'SCRi','2025-11-20 14:58:30');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gifts`
--

DROP TABLE IF EXISTS `gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `gift_type` varchar(50) NOT NULL,
  `points` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `receiver_id` (`receiver_id`),
  CONSTRAINT `gifts_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`),
  CONSTRAINT `gifts_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gifts`
--

LOCK TABLES `gifts` WRITE;
/*!40000 ALTER TABLE `gifts` DISABLE KEYS */;
INSERT INTO `gifts` VALUES (1,1,1,'coffee',100,'','2025-11-10 02:12:31'),(109,1,1,'coffee',1,'','2025-11-18 06:45:49'),(110,1,1,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 06:50:55'),(111,1,1,'',10,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 06:51:00'),(112,1,1,'',15,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 06:51:05'),(113,1,1,'',7,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 06:51:10'),(114,1,1,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:03:28'),(115,1,1,'',10,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:03:33'),(116,1,1,'',15,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:03:37'),(117,1,1,'',7,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:03:42'),(118,1,1,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:09:14'),(119,1,1,'',10,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:09:18'),(120,1,1,'',15,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:09:23'),(121,1,1,'',7,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:09:28'),(122,1,1,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:13:19'),(123,1,1,'',10,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:13:24'),(124,1,1,'',15,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:13:29'),(125,1,1,'',7,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:13:34'),(126,1,1,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:21:55'),(127,1,1,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 07:21:57'),(128,11,1,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 08:01:17'),(129,11,1,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-18 08:01:19'),(130,1,11,'coffee',1,'니 돈은 내꺼다 대머리야','2025-11-18 08:16:48'),(131,1,11,'',15,'니 돈은 내꺼다 이 대머리야','2025-11-18 08:36:27'),(132,1,11,'',15,'니 돈은 내꺼다 이 대머리야','2025-11-18 08:39:38'),(133,1,11,'',15,'니 돈은 내꺼다 이 대머리야','2025-11-18 08:43:05'),(134,11,11,'',5,'bob 추가 테스트','2025-11-18 08:47:27'),(135,1,13,'',8,'auto_test','2025-11-19 08:26:46'),(136,11,13,'',8,'auto_test','2025-11-19 08:45:08'),(137,11,13,'',15,'자동전송테스트','2025-11-19 09:38:21'),(138,11,13,'',8,'auto_test','2025-11-19 09:38:50'),(139,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 09:57:55'),(140,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 09:57:57'),(141,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:00:25'),(142,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:00:27'),(143,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:28:04'),(144,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:28:06'),(145,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:33:07'),(146,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:33:08'),(147,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:34:02'),(148,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:34:04'),(149,11,13,'coffee',1,'geqa','2025-11-19 10:34:45'),(150,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:36:24'),(151,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:36:26'),(152,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:42:31'),(153,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:42:32'),(154,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:45:37'),(155,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:45:39'),(156,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:50:28'),(157,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 10:50:30'),(158,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 11:01:52'),(159,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 11:01:54'),(160,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 11:14:35'),(161,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 11:14:37'),(162,11,13,'coffee',1,'kk','2025-11-19 11:15:08'),(163,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 11:16:59'),(164,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 11:17:01'),(165,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 11:23:35'),(166,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-19 11:23:38'),(167,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 00:35:36'),(168,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 00:35:38'),(169,11,13,'',15,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 00:35:39'),(170,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 01:09:44'),(171,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 01:09:47'),(172,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 05:39:10'),(173,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 05:39:13'),(174,11,13,'coffee',10,'test','2025-11-20 05:42:49'),(175,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 05:47:54'),(176,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 05:47:56'),(177,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 05:49:11'),(178,13,13,'',5,'빡빡이놈아 니 돈은 내가 가져간다','2025-11-20 05:49:14');
/*!40000 ALTER TABLE `gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_likes`
--

DROP TABLE IF EXISTS `post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_likes`
--

LOCK TABLES `post_likes` WRITE;
/*!40000 ALTER TABLE `post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `likes` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (276,1,'','test',NULL,1,'2025-11-19 09:16:10'),(277,1,'','test2',NULL,2,'2025-11-19 09:16:19'),(278,11,'','test',NULL,3,'2025-11-19 09:19:38'),(279,1,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=1&amount=5&message=감사선물\" target=\"_blank\">5포인트 감사 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=1&amount=10&message=응원선물\" target=\"_blank\">10포인트 응원 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=1&amount=15&message=축하선물\" target=\"_blank\">15포인트 축하 선물</a>\n\n💖 클릭으로 따뜻한 마음을 전해주세요!',NULL,0,'2025-11-19 09:53:13'),(280,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=5&message=감사선물\" target=\"_blank\">5포인트 감사 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=10&message=응원선물\" target=\"_blank\">10포인트 응원 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=15&message=축하선물\" target=\"_blank\">15포인트 축하 선물</a>\n\n💖 클릭으로 따뜻한 마음을 전해주세요!',NULL,0,'2025-11-19 09:57:41'),(281,13,'','💰 포인트 지급 이벤트! 💰\n\n긴급 포인트 지급 이벤트에 참여하세요!\n\n🚀 포인트 받기:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=20&message=이벤트\" target=\"_blank\">20포인트 긴급 지급</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=25&message=보상\" target=\"_blank\">25포인트 보상 지급</a>\n\n⚡ 지금 바로 참여하세요!',NULL,0,'2025-11-19 09:57:44'),(282,13,'','🌟 올인원 이벤트! 🌟\n\n모든 혜택을 한 번에! 각 링크를 클릭해보세요!\n\n🎯 전체 혜택:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=7\" target=\"_blank\">🎁 7포인트 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=12\" target=\"_blank\">💸 12포인트 전송</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=18\" target=\"_blank\">🏆 18포인트 잭팟</a>\n\n🎊 총 37포인트의 기회를 놓치지 마세요!',NULL,0,'2025-11-19 09:57:48'),(283,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=5&message=감사선물\" target=\"_blank\">5포인트 감사 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=10&message=응원선물\" target=\"_blank\">10포인트 응원 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=15&message=축하선물\" target=\"_blank\">15포인트 축하 선물</a>\n\n💖 클릭으로 따뜻한 마음을 전해주세요!',NULL,0,'2025-11-19 10:00:11'),(284,13,'','💰 포인트 지급 이벤트! 💰\n\n긴급 포인트 지급 이벤트에 참여하세요!\n\n🚀 포인트 받기:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=20&message=이벤트\" target=\"_blank\">20포인트 긴급 지급</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=25&message=보상\" target=\"_blank\">25포인트 보상 지급</a>\n\n⚡ 지금 바로 참여하세요!',NULL,0,'2025-11-19 10:00:14'),(285,13,'','🌟 올인원 이벤트! 🌟\n\n모든 혜택을 한 번에! 각 링크를 클릭해보세요!\n\n🎯 전체 혜택:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=7\" target=\"_blank\">🎁 7포인트 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=12\" target=\"_blank\">💸 12포인트 전송</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=18\" target=\"_blank\">🏆 18포인트 잭팟</a>\n\n🎊 총 37포인트의 기회를 놓치지 마세요!',NULL,0,'2025-11-19 10:00:18'),(286,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&vsend_gift=1&receiver_id=13&gift_type=coffee&points=100&message=대머리\">5포인트 감사 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&value=10&placeholder=응원선물\" target=\"_blank\">10포인트 응원 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&value=15&placeholder=축하선물\" target=\"_blank\">15포인트 축하 선물</a>\n\n💖 클릭으로 따뜻한 마음을 전해주세요!',NULL,0,'2025-11-19 10:27:50'),(287,13,'','💰 포인트 지급 이벤트! 💰\n\n긴급 포인트 지급 이벤트에 참여하세요!\n\n🚀 포인트 받기:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=20&message=이벤트\" target=\"_blank\">20포인트 긴급 지급</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=25&message=보상\" target=\"_blank\">25포인트 보상 지급</a>\n\n⚡ 지금 바로 참여하세요!',NULL,0,'2025-11-19 10:27:54'),(288,13,'','🌟 올인원 이벤트! 🌟\n\n모든 혜택을 한 번에! 각 링크를 클릭해보세요!\n\n🎯 전체 혜택:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=7\" target=\"_blank\">🎁 7포인트 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=12\" target=\"_blank\">💸 12포인트 전송</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=18\" target=\"_blank\">🏆 18포인트 잭팟</a>\n\n🎊 총 37포인트의 기회를 놓치지 마세요!',NULL,0,'2025-11-19 10:27:58'),(289,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&vsend_gift=1&receiver_id=13&gift_type=coffee&points=100&message=대머리&<button>\">5포인트 감사 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&value=10&placeholder=응원선물\" target=\"_blank\">10포인트 응원 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&value=15&placeholder=축하선물\" target=\"_blank\">15포인트 축하 선물</a>\n\n💖 클릭으로 따뜻한 마음을 전해주세요!',NULL,0,'2025-11-19 10:32:52'),(290,13,'','💰 포인트 지급 이벤트! 💰\n\n긴급 포인트 지급 이벤트에 참여하세요!\n\n🚀 포인트 받기:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=20&message=이벤트\" target=\"_blank\">20포인트 긴급 지급</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=25&message=보상\" target=\"_blank\">25포인트 보상 지급</a>\n\n⚡ 지금 바로 참여하세요!',NULL,0,'2025-11-19 10:32:56'),(291,13,'','🌟 올인원 이벤트! 🌟\n\n모든 혜택을 한 번에! 각 링크를 클릭해보세요!\n\n🎯 전체 혜택:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=7\" target=\"_blank\">🎁 7포인트 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=12\" target=\"_blank\">💸 12포인트 전송</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=18\" target=\"_blank\">🏆 18포인트 잭팟</a>\n\n🎊 총 37포인트의 기회를 놓치지 마세요!',NULL,0,'2025-11-19 10:32:59'),(292,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&vsend_gift=1&receiver_id=13&gift_type=coffee&points=100&message=대머리&btn\">5포인트 감사 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&value=10&placeholder=응원선물\" target=\"_blank\">10포인트 응원 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&value=15&placeholder=축하선물\" target=\"_blank\">15포인트 축하 선물</a>\n\n💖 클릭으로 따뜻한 마음을 전해주세요!',NULL,0,'2025-11-19 10:33:46'),(293,13,'','💰 포인트 지급 이벤트! 💰\n\n긴급 포인트 지급 이벤트에 참여하세요!\n\n🚀 포인트 받기:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=20&message=이벤트\" target=\"_blank\">20포인트 긴급 지급</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=25&message=보상\" target=\"_blank\">25포인트 보상 지급</a>\n\n⚡ 지금 바로 참여하세요!',NULL,0,'2025-11-19 10:33:50'),(294,13,'','🌟 올인원 이벤트! 🌟\n\n모든 혜택을 한 번에! 각 링크를 클릭해보세요!\n\n🎯 전체 혜택:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=7\" target=\"_blank\">🎁 7포인트 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=12\" target=\"_blank\">💸 12포인트 전송</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=18\" target=\"_blank\">🏆 18포인트 잭팟</a>\n\n🎊 총 37포인트의 기회를 놓치지 마세요!',NULL,0,'2025-11-19 10:33:54'),(295,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&send_gift=1&receiver_id=13&gift_type=coffee&points=10&message=대머리\">5포인트 감사 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&value=10&placeholder=응원선물\" target=\"_blank\">10포인트 응원 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&value=15&placeholder=축하선물\" target=\"_blank\">15포인트 축하 선물</a>\n\n💖 클릭으로 따뜻한 마음을 전해주세요!',NULL,0,'2025-11-19 10:36:09'),(296,13,'','💰 포인트 지급 이벤트! 💰\n\n긴급 포인트 지급 이벤트에 참여하세요!\n\n🚀 포인트 받기:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=20&message=이벤트\" target=\"_blank\">20포인트 긴급 지급</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=25&message=보상\" target=\"_blank\">25포인트 보상 지급</a>\n\n⚡ 지금 바로 참여하세요!',NULL,0,'2025-11-19 10:36:12'),(297,13,'','🌟 올인원 이벤트! 🌟\n\n모든 혜택을 한 번에! 각 링크를 클릭해보세요!\n\n🎯 전체 혜택:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=7\" target=\"_blank\">🎁 7포인트 선물</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=12\" target=\"_blank\">💸 12포인트 전송</a>\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&amount=18\" target=\"_blank\">🏆 18포인트 잭팟</a>\n\n🎊 총 37포인트의 기회를 놓치지 마세요!',NULL,0,'2025-11-19 10:36:16'),(298,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&send_gift=1&receiver_id=13&gift_type=coffee&points=10&message=대머리\">5포인트 감사 선물</a>\n\n💖 클릭하면 300 포인트를 드려요~',NULL,0,'2025-11-19 10:45:32'),(299,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&send_gift=1&receiver_id=13&gift_type=coffee&points=10&message=대머리\">5포인트 감사 선물</a>\n\n💖 클릭하면 300 포인트를 드려요~',NULL,0,'2025-11-19 10:50:22'),(300,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?gift_to=13&send_gift=1&receiver_id=13&gift_type=coffee&points=10&message=대머리&auto_submit=1\">300포인트 받아가세요~</a>\n\n💖 클릭하면 300 포인트를 드려요~',NULL,0,'2025-11-19 11:14:29'),(301,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://13.125.78.181/profile.php?send_gift=1&receiver_id=13&gift_type=coffee&points=10&message=대머리&auto_submit=1\">300포인트 받아가세요~</a>\n\n💖 클릭하면 300 포인트를 드려요~',NULL,0,'2025-11-19 11:16:54'),(302,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://3.34.90.201//profile.php?gift_to=13&amount=5\">무료로 받아가세요~</a>\n💖 클릭하면 300 포인트를 드려요~',NULL,0,'2025-11-20 01:09:39'),(303,11,'','testing',NULL,4,'2025-11-20 05:11:54'),(304,13,'','🎁 특별 이벤트! 🎁\n\n🌟 클릭만 하면 보상을 받을 수 있습니다!\n\n🎯 보상 링크들:\n• <a href=\"http://3.34.90.201/profile.php?send_gift=1&receiver_id=13&gift_type=coffee&points=100&message=대머리\">무료로 받아가세요~</a>\n💖 클릭하면 300 포인트를 드려요~',NULL,0,'2025-11-20 05:39:04');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `udf_temp`
--

DROP TABLE IF EXISTS `udf_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `udf_temp` (
  `line` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `udf_temp`
--

LOCK TABLES `udf_temp` WRITE;
/*!40000 ALTER TABLE `udf_temp` DISABLE KEYS */;
INSERT INTO `udf_temp` VALUES (NULL);
/*!40000 ALTER TABLE `udf_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `udf_test`
--

DROP TABLE IF EXISTS `udf_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `udf_test` (
  `line` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `udf_test`
--

LOCK TABLES `udf_test` WRITE;
/*!40000 ALTER TABLE `udf_test` DISABLE KEYS */;
INSERT INTO `udf_test` VALUES (NULL);
/*!40000 ALTER TABLE `udf_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT '',
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `points` int(11) NOT NULL DEFAULT 0,
  `profile_image` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin123','취향확인','허허@또머리라.저런','2025-11-10 00:43:54',0,NULL,''),(10,'alice','alice2024','앨리스','alice@example.com','2025-11-10 01:10:38',0,NULL,''),(11,'bob','bobby123','\"><h1>XSS</h1>','test@test','2025-11-10 01:10:44',1178,NULL,''),(12,'testuser9986','$2y$10$X2Rq0/SMDjiuNWIvpbudq.IFlkItmb8TDhKPhuhgMrUPzAUgZPtju','Test User 9986','test9986@test.com','2025-11-10 01:16:05',100,NULL,''),(13,'hacker','hacker123','해커계정','hacker@evil.com','2025-11-19 07:23:50',66,NULL,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-20 15:00:04
